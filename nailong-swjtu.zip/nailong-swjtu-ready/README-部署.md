# 奶龙国立交通大学.wiki — 生成结果

站点：
- 恶搞名：奶龙国立交通大学
- 正式学校：西南交通大学
- 跳转目标：https://www.swjtu.edu.cn/
- 中文域名：奶龙国立交通大学.wiki
- Punycode：xn--tlq56rswb7ix6fy19ebg5aw5za.wiki
- 首页：mascot 版式（盾形校徽更适合此版式）
- 校徽颜色：交大蓝 RGB (0, 121, 186)
- 校徽源图：用户提供的透明白色横向 Logo；本包提取左侧盾牌并转成交大蓝。
- 奶龙：用户提供图片，按白底四边洪水填充方式抠图。

## 直接部署
Cloudflare Pages 直接上传 `site/` 目录即可。

重要：
1. 先删除/停用原先把此域名直接 301/302 到西南交通大学的 Redirect Rule。
2. Pages 项目中添加自定义域名：奶龙国立交通大学.wiki
3. 如控制台要求 ASCII 域名，使用：xn--tlq56rswb7ix6fy19ebg5aw5za.wiki
4. 部署后访问根域名应先得到 200 页面，再由页面自动跳转至 https://www.swjtu.edu.cn/

## 如果要继续使用上游生成器
把本包的 `config.json` 覆盖仓库根目录的 config，
再把 `assets-src/` 下文件放到上游仓库同名目录。

注意：西南交通大学校徽是盾形，不适合上游 `rotate/index` 的“圆形文字环”逻辑；
因此本配置把 `homepage` 固定为 `mascot`。本包的 `site/index.html` 已针对盾形校徽直接生成，
可以优先直接部署 `site/`。
